<?php
class Student{
    private $name;
    private $number;
    private $email;
    private $program;
    private $subjectList = [];


    public function printStudentsSubjects(){

        echo "<table >
                <tr>
                    <th>Subject Name</th>
                    <th>Grade</th>
                    <th>Status</th>
                </tr>";
        foreach ($this->subjectList as $subject) {
            echo "<tr>
                    <td>{$subject['subjectName']}</td>
                    <td>{$subject['grade']}</td>
                    <td>{$subject['status']}</td>
                  </tr>";
        }
        echo "</table>";
    }


    public function subjectGradesAverage()
    {
       $sum = 0;
       $i = 0;
       foreach ($this->subjectList as $subject){
           $sum = $sum + $subject['grade'];
           $i = $i +1;
       }
       echo "Average: " . $sum/$i;
    }
    public function addSubjectList($subjectName, $grade)
    {
        $status = $grade >= 9.5 ? "Approved" : "Disapproved";
        $this->subjectList[] = [
            "subjectName" => $subjectName,
            "grade" => $grade,
            "status" => $status
        ];
    }



    public function getEmail()
    {
        return $this->email;
    }


    public function setEmail($email)
    {
        $this->email = $email;
    }


    public function getProgram()
    {
        return $this->program;
    }


    public function setProgram($program)
    {
        $this->program = $program;
    }


    public function getNumber()
    {
        return $this->number;
    }


    public function getSubjectList()
    {
        return $this->subjectList;
    }

    public function setNumber($number)
    {
        $this->number = $number;
    }
    public function getName()
    {
        return $this->name;
    }
    public function setName($name)
    {
        $this->name = $name;
    }

}
if ($_SERVER["REQUEST_METHOD"] == "POST"){
$student1 = new Student();
$student1->setName($_POST['studentName']);
$student1->setNumber($_POST['studentNum']);
$student1->setEmail($_POST['studentEmail']);
$student1->setProgram($_POST['studentProgram']);
$student1->addSubjectList($_POST['subjectName'],$_POST['subjectGrade']);

echo "Student Name: " . $student1->getName() . "\n";
echo "Student Number: " . $student1->getNumber() . "\n";
echo "Student Email: " . $student1->getEmail() . "\n";
echo "Student Program: " . $student1->getProgram() . "\n";
$student1->subjectGradesAverage();
$student1->printStudentsSubjects();

}



